# BridgeAI-Agent 第2章 v1.0

本包包含第二章Markdown源文件及3幅原创架构图。

- BridgeAI-Agent_Chapter2_v1.0.md
- images/fig2-1.png
- images/fig2-5.png
- images/fig2-8.png

作者：周仙通
单位：浙江悟联信息科技有限公司
